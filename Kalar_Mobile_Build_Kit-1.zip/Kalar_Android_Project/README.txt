KALAR ANDROID PROJECT
Package: com.muhamad.kalar
App name: Kalar
This is an Android Studio project that wraps the supplied offline-first Kalar web app in an Android WebView.

BUILD APK:
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Extract this ZIP.
3. In Android Studio choose File > Open and select the Kalar_Android_Project folder.
4. Allow Gradle sync and install any prompted SDK components.
5. For a test APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio shows the APK location, usually app/build/outputs/apk/debug/app-debug.apk.
7. For a shareable release APK: Build > Generate Signed Bundle / APK > APK, then create and safely keep your signing key.

NOTES:
- This environment does not have the Android SDK or Gradle installed, so it cannot compile/sign an APK here.
- The app shell and main pages load locally from the APK and do not require login.
- Facebook pages and phone calls need internet/phone service and open only after tapping.
- Facebook live feeds, live weather, authentic profile photos and authentic castle photographs are not bundled; the supplied page links are listed and launch on tap.
- Religious dates depend on official moon sighting; check official dates each year.

APP ICON
The launcher icon is the exact Kalar logo image supplied by the user. The installed app name is Kalar.

IMPORTANT
This folder is Android Studio source code, not an installable APK. Build a debug APK in Android Studio using Build > Build Bundle(s) / APK(s) > Build APK(s). Then transfer the generated app-debug.apk to the Android phone and tap it to install. Android may ask to allow installation from that file app.
